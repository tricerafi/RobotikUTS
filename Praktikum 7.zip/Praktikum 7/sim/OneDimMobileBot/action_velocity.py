# @obj: Simulate robot actions for OneDimMobileBot
# @author: vektor dewanto

import numpy as np
import math

#action ada 2 tupel, action = (v_trans (x/cm), v_rot(x/rad))
def move(action, pose, grid_map):
#def move(u, x_past, m):
    #grid_map['grid'][(x,y)]
    ''' 
    Move the robot abs(u) to the right if (u>0) or to the left if (u<0) with some movement errors.
    The control u is represented by an odometry delta.
    '''
    #extract information
    v = action[0]
    w = action[1]
    x = pose[0]
    y = pose[1]
    theta = pose[2]
    
    # Set the (true) action error model
    mu = 0.0
    std = 0.25

    #set alpha & delta t
    a1=0.01
    a2=0.01
    a3=0.01
    a4=0.01
    a5=0.01
    a6=0.01
    dt=1 #konstan
    
    #simulating error
    std_v = (a1*math.fabs(v)) + (a2*math.fabs(w))
    std_w = (a3*math.fabs(v)) + (a4*math.fabs(w))
    std_gamma = (a5*math.fabs(v)) + (a6*math.fabs(w))
    err_v = np.random.normal(mu, std_v)
    err_w = np.random.normal(mu, std_w)
    
    va = v + err_v
    wa = w + err_v
    gamma = np.random.normal(mu, std_gamma)

    #find new pose
    xa = x - (va/wa)*math.sin(theta) + (va/wa)*math.sin(theta+(wa*dt))
    ya = y + (va/wa)*math.cos(theta) - (va/wa)*math.cos(theta+(wa*dt))
    thetaa = theta + (wa*dt) + (gamma*dt)

    newpose = (xa, ya, thetaa)
    if xa > grid_map['size'][0] or ya > grid_map['size'][1] or xa < 0 or ya <0:
        return pose
    elif grid_map['grid'][(xa,ya)] != 0:
        return pose
    else:
      return newpose

#xm=0
#ym=0
#thetah=0

#poses=(xm,ym,thetah)
#act=(10,0)

#newpos = move(act,poses)

#print newpos



