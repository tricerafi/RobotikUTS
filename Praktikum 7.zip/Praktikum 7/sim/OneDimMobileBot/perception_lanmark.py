#!/usr/bin/python

import numpy as np
import math
from util.ray_casting import ray_cast
from util.ray_casting import get_grid_idx

def sense_landmark(pose, grid_map):
    result = []
	
	# Set the (true) action error model
    mu = 0.0
    std_range = 2
    std_angle = math.pi/8
    std_color = 2
    
    for i in range(8):
        newPose = (pose[0],pose[1],pose[2]+(math.pi/4*i))
        hit,a = ray_cast(newPose, grid_map)    
        print '(final) hit=', hit, a
        err_range = np.random.normal(mu, std_range)
        err_angle = np.random.normal(mu, std_angle)
        err_colour = np.random.normal(mu, std_color)
        if grid_map['grid'][a] != 0 and grid_map['grid'][a] != 1:
            centerLandmark = (a[0]+0.5,a[1]+0.5)
            
            true_range = math.sqrt(  (centerLandmark[0]-pose[0])**2 + (centerLandmark[1]-pose[1])**2  )
            sensed_range = true_range + err_range;

            true_colour = grid_map['grid'][a]
            sensed_colour = true_colour + err_colour
            
            true_angle = math.atan2((centerLandmark[1]-pose[1]),(centerLandmark[0] -pose[0]))
            sensed_angle = true_angle + err_angle
        
            #print 'angle', angle
            result.append((sensed_range,sensed_colour,sensed_angle));
        else:
            result.append(())
		
    return result

def test():
    # Construct the occupancy grid map
    grid_map = {'size': (10,10), 'res': 1.0}

    grid =  [1,1,1,1,1,1,1,1,1,1,\
             1,0,0,0,0,0,0,0,0,1,\
             1,0,0,0,0,0,0,0,0,1,\
             1,0,0,0,0,0,0,0,0,1,\
             1,0,0,0,5,0,0,0,0,1,\
             1,0,0,0,0,0,0,0,0,1,\
             1,0,0,0,0,0,0,0,0,1,\
             1,0,0,0,0,0,0,0,0,1,\
             1,0,0,0,0,0,0,0,0,1,\
             1,1,1,1,1,1,1,1,1,1]
    assert len(grid)==grid_map['size'][0]*grid_map['size'][1], 'grid size is mismatched'
    grid = np.asarray(grid)
    grid = grid.reshape(grid_map['size'][0], grid_map['size'][1])
    grid_map['grid'] = grid

    #
    x = 4.000001
    y = 4.000002
    theta = math.pi/2
    pose = (x, y, theta)
    
    print 'start', (pose[0],pose[1]), grid_map['grid'][(pose[0],pose[1])]
    
    abc = sense_landmark(pose, grid_map)
    for i in range(len(abc)):
        print i
        print 'range ', abc[i][0]
        print 'color ', abc[i][1]
        print 'angle ', abc[i][2]
        print '-----------------------' 

def main():    
    test()
    
if __name__ == "__main__":
    main()
