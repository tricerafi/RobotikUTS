#!/usr/bin/python

# @obj: to reproduce figure 8.11 from the book Prob. Robotics by S. Thrun
# @author: vektor dewanto

import numpy as np
import math
import util.plotter as plotter
import sim.OneDimMobileBot.action_velocity as action
import sim.OneDimMobileBot.perception as sensor
import MCL.standard as MCL
import matplotlib.pyplot as plt
import matplotlib.cm as cmx
from matplotlib import colors
from perception_model.modela import measurement_model_total

from sim.OneDimMobileBot.perception_lanmark import sense_landmark
from matplotlib.backends.backend_pdf import PdfPages

# Init
print 'hello :)'
plots = []

t_max = 10
T = range(t_max+1)# contains a seq. of discrete time step from 0 to t_max
n_particle = 300# fixed, hardcoded

grid_map2 = {'size': (5,5), 'res': 1.0, 'landmark_A': (2,0,50), 'landmark_B':(0,1,150), 'landmark_C':(2,4,212)}

grid_map = {'size': (20,20), 'res': 1.0, 'landmark_A': (3,6,50), 'landmark_B':(1,0,150), 'landmark_C':(0,3,212)}

grid = [1,1,1,4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,\
        3,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,0,0,2,0,0,0,1,1,1,1,1,1,1,0,0,1,\
        1,1,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,\
        1,0,0,0,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,\
        1,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,\
        1,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,1,\
        1,0,0,1,1,1,1,0,0,0,1,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,1,\
        1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,\
        1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,\
        1,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,1,\
        1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,\
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]

gridA = grid

grid2 = [1,1,50,1,1,\
        1,0,0,0,1,\
        1,0,0,0,1,\
        1,0,0,0,1,\
        1,1,1,1,1]


assert len(grid)==grid_map['size'][0]*grid_map['size'][1], 'grid size is mismatched'
grid = np.asarray(grid)
grid = grid.reshape(grid_map['size'][0], grid_map['size'][1])
grid = np.transpose(grid)
grid_map['grid'] = grid
print 'warna 50 =',grid_map['grid'][(6,3)]
x = 3.500001
y = 3.200002
theta = math.pi/2
pose = (x, y, theta)
print 'start', (pose[0],pose[1])

Z_total = sense_landmark(pose, grid_map)
for i in range(len(Z_total)):
    if len(Z_total[i]) > 0:
        print i
        print 'range ', Z_total[i][0]
        print 'color ', Z_total[i][1]
        print 'angle ', Z_total[i][2]
        print '-----------------------'

#x1 = 2.000001
#y1 = 1.000002
#theta1 = 0
#pose1 = (x1, y1, theta1)
#res = measurement_model_total(Z_total,pose1,grid_map)
#print res

U = [None, (1,1,0.0001), (-2,1,0.0001), (1.5,1,0.0001),(0.00001,1,math.pi/2),(1,1,0.005),(-2,1,0.0000001),(1,1,0.0001), (-2,1,0.0001), (1.5,1,0.0001),(0.00001,1,math.pi/2)]
# hardcoded: a list of desired actions in odometry motion model
#assert (len(U)>=len(T)), 'len(U)<len(T)'

# Plot the map
plt.subplot(1,1,1)
plt.pcolormesh(grid_map['grid'], edgecolors='k', linewidths=0.1, cmap=colors.ListedColormap(['w','b','m','y','r','g']))
plt.title('Particle at t = 0')

# At t=0, initiate X with n_particle parx_starticles drawn from a uniform distribution (since this is a global loc. problem)
X_tmp = np.random.uniform(1.0, 18, n_particle)
Y_tmp = np.random.uniform(1.0, 18, n_particle)
THETA_tmp = np.random.uniform(0.0, math.pi*2.0, n_particle)

#X_tmp = [x]*n_particle
#Y_tmp = [y]*n_particle
#THETA_tmp = [theta]*n_particle
XYTHETA_tmp = zip(X_tmp, Y_tmp, THETA_tmp)

#XYTHETA_tmp = pose1
W = [1.0/n_particle] * n_particle# uniform
X = zip(XYTHETA_tmp, W)

# Plot positions, the color corresponds to the weight
ax = plt.axes()
ax.scatter([e[0][0] for e in X], [e[0][1] for e in X], c=[e[1] for e in X], marker='o', s=20, cmap=cmx.jet)

# Plot bearings
for e in X:
    x = e[0][0]
    y = e[0][1]
    theta = e[0][2]

    # convert polar to cartesian coord
    r = 0.1
    dx = r * math.cos(theta)
    dy = r * math.sin(theta)

    ax.arrow(x, y, dx, dy, head_width=0.05, head_length=0.1, fc='k', ec='k')

plt.show()

# Put the robot now!
x_star = pose
#plots.append(plotter.plot(X, m, x_star, t=0))
counter = 0
# Localize!
for t in T[1:]:
    print ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> t=", t
    plt.subplot(1,1,1)
    plt.pcolormesh(grid_map['grid'], edgecolors='k', linewidths=0.1, cmap=colors.ListedColormap(['w','b','m','y','r','g']))
    counter = counter + 1
    plt.title('Particle at t = ' + `counter`)
    ax = plt.axes()
    # _Simulate_ an action
    u = U[t]
    print 'u_star=', u

    #if t==4:
    #    x_star=(1.800001,1.500001,math.pi/4)
    #else:
    #    x_star = action.move(u, x_star, grid_map)

    print 'x_star=', x_star
    ax.scatter(x_star[0],x_star[1],s=500,marker='x')
    ax.arrow(x_star[0], x_star[1], 0.1 * math.cos(x_star[2]), 0.1 * math.sin(x_star[2]), head_width=0.05, head_length=0.1, fc='k', ec='k')
    # _Simulate_ an observation

    z = sense_landmark(x_star, grid_map)
    print 'z_star= ', z

    X = MCL.run(X, u, z, grid_map)
#    plots.append(plotter.plot(X, m, x_star, t))

    # Plot the map
    #plt.subplot(1,1,1)
    #plt.pcolormesh(grid_map['grid'], edgecolors='k', linewidths=0.1, cmap=colors.ListedColormap(['w','b','m','y','r','g']))
    #plt.title('Particle at t = ')
    # Plot positions, the color corresponds to the weight
    #ax = plt.axes()
    ax.scatter([e[0][0] for e in X], [e[0][1] for e in X], c=[e[1] for e in X], marker='o', s=50, cmap=cmx.jet)

    max = 0
    ans = (0,0)
    for a in X:
        if (a[1] > max):
            ans = (a[0][0],a[0][1])
            max = ans[1]

    print 'max partikel', ans
    print 'posisi robot', (x_star[0], x_star[1])
    print 'error', math.sqrt( (ans[0]-x_star[0] )**2 + (ans[1]-x_star[1])**2 )

    #Plot bearings
    for e in X:
        x = e[0][0]
        y = e[0][1]
        theta = e[0][2]

        # convert polar to cartesian coord
        r = 0.1
        dx = r * math.cos(theta)
        dy = r * math.sin(theta)
        ax.arrow(x, y, dx, dy, head_width=0.05, head_length=0.1, fc='k', ec='k')

    plt.show()


# Closure
# with PdfPages('plot.pdf') as pdf:
#    for p in plots:
#        pdf.savefig(p)

print "mission accomplished: bye :)"
