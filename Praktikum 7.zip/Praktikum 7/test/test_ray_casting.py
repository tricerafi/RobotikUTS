#!/usr/bin/python

import numpy as np
import math
from CSUIBotClass2014.util.ray_casting import ray_cast
from CSUIBotClass2014.util.ray_casting import get_grid_idx
# Construct the occupancy grid map
grid_map = {'size': (10,10), 'res': 1.0}

grid =  [1,1,1,1,1,1,1,1,1,1,\
         1,0,0,0,0,0,0,0,0,1,\
         1,0,0,0,0,0,0,0,0,1,\
         1,0,0,0,0,0,0,0,0,1,\
         1,0,0,0,0,0,0,0,0,1,\
         1,0,0,0,0,0,0,0,0,1,\
         1,0,0,0,0,0,0,0,0,1,\
         1,0,0,0,0,0,0,0,0,1,\
         1,0,0,0,0,0,0,0,0,1,\
         1,1,1,1,1,1,1,1,1,1]
assert len(grid)==grid_map['size'][0]*grid_map['size'][1], 'grid size is mismatched'
grid = np.asarray(grid)
grid = grid.reshape(grid_map['size'][0], grid_map['size'][1])
grid_map['grid'] = grid

#
x = 3.000001
y = 5.000002
theta = 0#math.pi/4*8
pose = (x, y, theta)
#hit,a = ray_cast(pose, grid_map)

#
result = []
for i in range(8):
    newPose = (pose[0],pose[1],pose[2]+(math.pi/4*i))
    hit,a = ray_cast(newPose, grid_map)
    print 'start', (pose[0],pose[1])
    print '(final) hit=', hit
    rangee = math.sqrt((pose[0]-hit[0])*(pose[0]-hit[0]) + (pose[1]-hit[1])*(pose[1]-hit[1]))    
    colour = grid_map['grid'][a]    
    angle = math.atan2((hit[1]-pose[1]),(hit[0]-pose[0]))
    print 'angle', angle
    result.append((rangee,colour,angle));

#for i in range(len(result)):
#    print 'range ',i, result[i][0]
#    print 'color ',i, result[i][1]
#    print 'angle ',i, result[i][2]
    
