import numpy as np
import math

def sample_motion_model(u, x_past, grid_map):
    x = x_past[0]
    y = x_past[1]
    theta = x_past[2]

    rot1 = u[0]
    rot2 = u[1]
    trans = u[2]

    # Set the (true) action error model
    mu = 0.1
    std = 0.25

    #set alpha & delta t
    a1=0.01
    a2=0.01
    a3=0.01
    a4=0.01
    a5=0.01
    a6=0.01
    dt=1 #konstan

    #simulating error
    #do your implemetation!

    std_rot1 = a1*abs(rot1) + a2*trans
    std_rot2 = a1*abs(rot2) + a2*trans
    std_trans = a3*trans + a4*(abs(rot1) + abs(rot2))

    err_rot1 = np.random.normal(mu, std_rot1)
    err_rot2 = np.random.normal(mu, std_rot2)
    err_trans = np.random.normal(mu, std_trans)

    rot1a = rot1 + err_rot1
    rot2a = rot2 + err_rot2
    transa = trans + err_trans

    #find new pose
    #do your implementation!
    # lihat slide 21 bab 5

    xa = x + transa * math.cos(theta + rot1a)
    ya = y + transa * math.sin(theta + rot1a)
    thetaa = rot1a + rot2a

    newpose = (xa, ya, thetaa)
    if xa > grid_map['size'][0] or ya > grid_map['size'][1] or xa < 0 or ya <0:
        return x_past
    elif grid_map['grid'][(xa,ya)] != 0:
        return x_past
    else:
      return newpose


    ''' Assumptions:
    1) Use the odometry motion model, u = (desired) dx
    2) Odometry error is modeled using gaussian distribution
    # Set the odometry error model
    #mu = 0.
    std = 0.25

    dx_bar = u
    err = np.random.normal(mu, std)

    dx = dx_bar + err
    x = x_past + dx

    return x
    '''
