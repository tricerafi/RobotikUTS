#!/usr/bin/python
import math
import numpy as np
import scipy.stats as stat
from util.ray_casting import ray_cast
from util.ray_casting import get_grid_idx
from sim.OneDimMobileBot.perception_lanmark import sense_landmark

def get_corespondent_landmark(z):
    if z[1] < 100 :
        return 'landmark_A'
    elif z[1] < 200:
        return 'landmark_B'
    else:
        return 'landmark_C'
def measurement_model_total(z_total,pose,grid_map):
    p_total = 1
    count = 0
    for i in range(8):
        if len(z_total[i]) == 0:
            count += 1
            continue

        corr = get_corespondent_landmark(z_total[i])

        p_total *= measurement_model(z_total[i], corr, pose, grid_map)
        #print 'p sementara',i,p_total

    if count == 8:
        return 0
    return p_total

def get_prob(x_in,sigma,epsilon):
    #print 'x_in',x_in
    cdf_lo = stat.norm(loc= 0, scale= sigma).cdf(x_in - epsilon)
    #print 'cdf_lo', cdf_lo
    cdf_hi = stat.norm(loc= 0, scale= sigma).cdf(x_in + epsilon)
    #print 'cdf_hi', cdf_hi
    return cdf_hi - cdf_lo

def measurement_model(z, corr, pose, grid_map):
    j = corr
    landmark_pose = (grid_map[j][0]+0.5, grid_map[j][1]+0.5)

    estimated_sigma_r = 5 # from experiments
    estimated_sigma_phi = math.pi / 4
    estimated_sigma_colour = 5

    eps_range = 5
    eps_phi = math.pi/4
    eps_colour = 5

    #do your implementation here!
    d_hat = math.sqrt((pose[0] - landmark_pose[0]) ** 2 + (pose[1] - landmark_pose[1]) ** 2)
    a_hat = math.atan2(pose[1] - landmark_pose[1], pose[0] - landmark_pose[0])
    q_d = get_prob(z[0] - d_hat, estimated_sigma_r, eps_range)
    q_a = get_prob(z[2] - a_hat, estimated_sigma_phi, eps_phi)
    q_sign = get_prob(z[1] - grid_map[j][2], estimated_sigma_colour, eps_colour)
    q = q_d * q_a * q_sign
    return q

def test():
    print 'masuk'
    grid_map = {'size': (20,20), 'res': 1.0, 'landmark_A': (6,6,50), 'landmark_B':(6,19,150), 'landmark_C':(19,7,212)}

    grid = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,\
            1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,0,0,50,0,0,0,0,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,0,0,1,0,0,0,1,1,1,1,1,1,1,0,0,1,\
            1,1,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,\
            1,0,0,0,0,0,1,0,0,0,1,0,0,1,0,0,1,0,0,1,\
            1,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,150,\
            1,0,0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,1,\
            1,0,0,1,1,1,1,0,0,0,1,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,1,0,0,0,0,0,1,1,1,1,0,0,0,0,0,1,\
            1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,1,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,\
            1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,1,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,\
            1,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,1,\
            1,0,0,0,0,0,0,212,0,0,0,0,0,0,0,0,0,0,0,1,\
            1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1]

    assert len(grid)==grid_map['size'][0]*grid_map['size'][1], 'grid size is mismatched'
    grid = np.asarray(grid)
    grid = grid.reshape(grid_map['size'][0], grid_map['size'][1])
    grid_map['grid'] = grid

    #pose robot
    x = 2.000001
    y = 2.000002
    theta = 0
    pose = (x, y, theta)

    Z_total = sense_landmark(pose, grid_map)
    for i in range(len(Z_total)):
        print Z_total[i]

    #pose particle
    x_p = 1.001
    y_p = 2.0001
    theta_p = 0
    pose_p = (x_p, y_p, theta_p)

    res = measurement_model_total(Z_total, pose_p, grid_map)
    print res

def main():
    test()

if __name__ == "__main__":
    main()
